The changelog is now available at https://z2jh.jupyter.org/en/latest/changelog.html.
